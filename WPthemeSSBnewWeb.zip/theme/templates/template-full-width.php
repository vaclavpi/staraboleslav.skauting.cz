<?php
/**
 * Template Name: Na celou šířku webu
 * Template Post Type: post, page
 *
 * @package WordPress
 */

get_template_part( 'singular' );